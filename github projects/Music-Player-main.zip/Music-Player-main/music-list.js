let allMusic = [
    {
        name: "Shape-of-You",
        artist: "Ed Sheeran",
        img: "music-1",
        src: "music-1"
    },
    {
        name: "Calm-Down",
        artist: "Rema, Selena Gomez",
        img: "music-2",
        src: "music-2"
    },
    {
        name: "Let Me Down Slowly",
        artist: "Alec Benjamin",
        img: "music-3",
        src: "music-3"
    },
    {
        name: "Love Me Like You Do",
        artist: "Ellie Goulding",
        img: "music-4",
        src: "music-4"
    },
    {
        name: "Starboy",
        artist: "The Weeknd",
        img: "music-5",
        src: "music-5"
    },
    {
        name: "Girls Like You",
        artist: "Maroon 5",
        img: "music-6",
        src: "music-6"
    },
    {
        name: "On My Way",
        artist: "Alan Walker",
        img: "music-7",
        src: "music-7"
    },
    {
        name: "Sorry",
        artist: "Justin Beiber",
        img: "music-8",
        src: "music-8"
    },
    {
        name: "Sugar and Brownies",
        artist: "Dharia",
        img: "music-9",
        src: "music-9"
    },
    {
        name: "Faded",
        artist: "Alan Walker",
        img: "music-10",
        src: "music-10"
    },
];
